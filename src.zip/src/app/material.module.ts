import { NgModule } from '@angular/core';

import {
    MatSidenavModule,
    MatToolbarModule,
    MatIconModule,
    MatListModule,
    MatCardModule,
    MatGridListModule,
    MatCheckboxModule,
    MatMenuModule,
    MatButtonToggleModule,
    MatTreeModule,
    MatBadgeModule,
    MatProgressSpinnerModule,


} from '@angular/material';



@NgModule({
    imports: [
        MatSidenavModule,
        MatToolbarModule,
        MatIconModule,
        MatListModule,
        MatCardModule,
        MatGridListModule,
        MatCheckboxModule,
        MatMenuModule,
        MatButtonToggleModule,
        MatTreeModule,
        MatBadgeModule,
        MatProgressSpinnerModule


    ],
    exports: [
        MatSidenavModule,
        MatToolbarModule,
        MatIconModule,
        MatListModule,
        MatCardModule,
        MatGridListModule,
        MatCheckboxModule,
        MatMenuModule,
        MatButtonToggleModule,
        MatTreeModule,
        MatBadgeModule,
        MatProgressSpinnerModule


    ]
})

export class MaterialModule { }